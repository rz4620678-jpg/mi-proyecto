<?php
class ClienteController {
    static function listar($in = []) {
        $l = '%' . ($_GET['q'] ?? '') . '%';
        Res::json(q("SELECT c.*,
            (SELECT IFNULL(SUM(saldo),0) FROM v_facturas_completo v WHERE v.cliente_id=c.id AND v.estado<>'ANULADA') saldo,
            (SELECT COUNT(*) FROM facturas f WHERE f.cliente_id=c.id) facturas,
            (SELECT MAX(f.emision) FROM facturas f WHERE f.cliente_id=c.id) ultima_factura
            FROM clientes c WHERE razon_social LIKE ? OR ruc LIKE ? ORDER BY razon_social", [$l, $l])->fetchAll());
    }
    static function guardar($in = []) {
        if (empty($in['razon_social']) || empty($in['ruc'])) Res::fail('Razón social y RUC son obligatorios');
        if (!preg_match('/^\d{11}$/', $in['ruc'])) Res::fail('El RUC debe tener 11 dígitos');
        $v = [strtoupper($in['razon_social']), $in['ruc'], $in['telefono'] ?? '', $in['email'] ?? '', $in['direccion'] ?? ''];
        if (!empty($in['id'])) q("UPDATE clientes SET razon_social=?,ruc=?,telefono=?,email=?,direccion=? WHERE id=?", [...$v, $in['id']]);
        else q("INSERT INTO clientes(razon_social,ruc,telefono,email,direccion) VALUES(?,?,?,?,?)", $v);
        Res::json(['ok' => 1]);
    }
    static function eliminar($in = []) {
        if (q("SELECT COUNT(*) FROM facturas WHERE cliente_id=?", [$in['id'] ?? 0])->fetchColumn()) Res::fail('No se puede eliminar: el cliente tiene facturas');
        q("DELETE FROM clientes WHERE id=?", [$in['id']]); Res::json(['ok' => 1]);
    }
}
