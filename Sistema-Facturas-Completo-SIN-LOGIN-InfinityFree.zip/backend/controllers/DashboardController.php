<?php
class DashboardController {
    static function resumen($in = []) {
        $anio = trim((string)($_GET['anio'] ?? ''));
        $todos = $anio === '' || strtolower($anio) === 'todos';
        if (!$todos && (!ctype_digit($anio) || strlen($anio) !== 4)) Res::fail('El año no es válido');
        // El mismo año limita los indicadores, estados, deuda y cobros.
        $filtro = $todos ? '' : ' AND anio=?';
        $parametros = $todos ? [] : [(int)$anio];
        $k = q("SELECT IFNULL(SUM(total),0) facturado,IFNULL(SUM(cobrado),0) cobrado,IFNULL(SUM(saldo),0) pendiente,
            IFNULL(SUM(utilidad),0) utilidad,IFNULL(SUM(total_neto),0) neto,IFNULL(SUM(estado='VENCIDA'),0) vencidas
            FROM v_facturas_completo WHERE estado<>'ANULADA'$filtro", $parametros)->fetch();
        $k['anuladas'] = q("SELECT COUNT(*) FROM facturas WHERE anulada=1" . ($todos ? '' : ' AND YEAR(emision)=?'), $parametros)->fetchColumn();
        $k['cobros_mes'] = q("SELECT IFNULL(SUM(monto),0) FROM cobros WHERE MONTH(fecha)=MONTH(CURDATE())" . ($todos ? '' : ' AND YEAR(fecha)=?'), $parametros)->fetchColumn();
        $k['clientes'] = q("SELECT COUNT(DISTINCT cliente_id) FROM v_facturas_completo WHERE estado<>'ANULADA'$filtro", $parametros)->fetchColumn();
        $detalleFiltro = $todos ? '' : ' AND YEAR(f.emision)=?';
        $k['unidades_vendidas'] = q("SELECT IFNULL(SUM(d.cantidad),0) FROM factura_detalle d JOIN facturas f ON f.id=d.factura_id JOIN productos p ON p.id=d.producto_id WHERE f.anulada=0 AND p.es_ajuste=0$detalleFiltro", $parametros)->fetchColumn();
        $k['lineas_venta'] = q("SELECT COUNT(*) FROM factura_detalle d JOIN facturas f ON f.id=d.factura_id JOIN productos p ON p.id=d.producto_id WHERE p.es_ajuste=0$detalleFiltro", $parametros)->fetchColumn();
        $k['productos_distintos'] = q("SELECT COUNT(DISTINCT d.producto_id) FROM factura_detalle d JOIN facturas f ON f.id=d.factura_id JOIN productos p ON p.id=d.producto_id WHERE f.anulada=0 AND p.es_ajuste=0$detalleFiltro", $parametros)->fetchColumn();
        $k['productos_catalogo'] = q("SELECT COUNT(*) FROM productos WHERE es_ajuste=0")->fetchColumn();
        $k['estados'] = q("SELECT estado,COUNT(*) n FROM v_facturas_completo WHERE 1$filtro GROUP BY estado", $parametros)->fetchAll();
        $k['meses'] = q("SELECT MONTH(fecha) m,SUM(monto) t FROM cobros" . ($todos ? '' : ' WHERE YEAR(fecha)=?') . " GROUP BY m ORDER BY m", $parametros)->fetchAll();
        $k['top'] = q("SELECT cliente,SUM(saldo) deuda FROM v_facturas_completo WHERE estado NOT IN('ANULADA','COBRADA')$filtro GROUP BY cliente ORDER BY deuda DESC LIMIT 5", $parametros)->fetchAll();
        $k['anios'] = q("SELECT DISTINCT anio FROM v_facturas WHERE emision IS NOT NULL ORDER BY anio DESC")->fetchAll(PDO::FETCH_COLUMN);
        Res::json($k);
    }
}
