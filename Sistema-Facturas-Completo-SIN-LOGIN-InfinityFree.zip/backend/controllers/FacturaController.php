<?php
class FacturaController {
    private static function sincronizarPreciosCatalogo(array $productoIds): void {
        foreach (array_unique(array_map('intval', $productoIds)) as $productoId) {
            if ($productoId < 1) continue;
            $precio = q("SELECT d.precio
                FROM factura_detalle d
                JOIN facturas f ON f.id = d.factura_id
                WHERE d.producto_id = ? AND f.anulada = 0
                ORDER BY f.emision DESC, f.id DESC, d.id DESC
                LIMIT 1", [$productoId])->fetchColumn();
            if ($precio !== false)
                q("UPDATE productos SET precio=? WHERE id=? AND es_ajuste=0",
                    [precioUnitarioConIgv($precio), $productoId]);
        }
    }
    static function listar($in = []) {
        $w = '1'; $p = [];
        if (!empty($_GET['anio'])) {
            if (strtolower((string)$_GET['anio']) !== 'todos') {
                if (!ctype_digit((string)$_GET['anio']) || strlen((string)$_GET['anio']) !== 4) Res::fail('El año no es válido');
                $w .= ' AND anio=?'; $p[] = (int)$_GET['anio'];
            }
        }
        if (!empty($_GET['cliente_id'])) { $w .= ' AND cliente_id=?'; $p[] = (int)$_GET['cliente_id']; }
        if (!empty($_GET['estado'])) { $w .= ' AND estado=?'; $p[] = $_GET['estado']; }
        if (!empty($_GET['q'])) {
            $l = '%' . $_GET['q'] . '%';
            $w .= ' AND (numero LIKE ? OR nro_guia LIKE ? OR nro_oc LIKE ? OR cliente LIKE ? OR ruc LIKE ?)';
            array_push($p, $l, $l, $l, $l, $l);
        }
        Res::json(q("SELECT * FROM v_facturas_completo WHERE $w ORDER BY id DESC", $p)->fetchAll());
    }
    static function detalle($in = []) {
        $w = '1'; $p = [];
        if (!empty($_GET['factura_id'])) { $w .= ' AND d.factura_id=?'; $p[] = $_GET['factura_id']; }
        if (!empty($_GET['q'])) { $w .= ' AND p.nombre LIKE ?'; $p[] = '%' . $_GET['q'] . '%'; }
        $rows = q("SELECT d.*,f.numero factura,p.nombre producto,p.marca,p.presentacion,p.unidad,p.es_ajuste
            FROM factura_detalle d JOIN facturas f ON f.id=d.factura_id JOIN productos p ON p.id=d.producto_id
            WHERE $w ORDER BY d.factura_id DESC,d.id", $p)->fetchAll();
        foreach ($rows as &$row) $row['precio'] = precioUnitarioConIgv($row['precio']);
        unset($row);
        Res::json($rows);
    }
    static function pendientes($in = []) {
        $exists = q("SELECT COUNT(*) FROM information_schema.tables
            WHERE table_schema=DATABASE() AND table_name='pendientes_importacion'")->fetchColumn();
        if (!$exists) Res::fail('Falta instalar la migración backend/pendientes_importacion.sql para consultar los registros incompletos.', 409);
        Res::json(q("SELECT id,numero,anio,subtotal_excel,igv_excel,total_excel,fuente,nota,creado_en
            FROM pendientes_importacion ORDER BY numero")->fetchAll());
    }
    // Crea o edita (si viene id) una factura con sus ítems
    static function guardar($in = []) {
        $items = array_values(array_filter($in['items'] ?? [], fn($i) => !empty($i['producto_id']) && ($i['cantidad'] ?? 0) > 0));
        if (empty($in['cliente_id']) || !$items) Res::fail('Elige un cliente y al menos un producto');
        foreach ($items as $item)
            if (!isset($item['precio']) || !is_numeric($item['precio']) || (float)$item['precio'] < 0)
                Res::fail('Ingresa un precio unitario válido para cada producto');
        $emision = $in['emision'] ?? '';
        $fecha = DateTime::createFromFormat('!Y-m-d', $emision);
        if (!$fecha || $fecha->format('Y-m-d') !== $emision) Res::fail('Ingresa una fecha de emisión válida');
        // Valida los campos opcionales antes de guardar en la base del cliente.
        $guia = trim((string)($in['nro_guia'] ?? ''));
        $orden = trim((string)($in['nro_oc'] ?? ''));
        if (mb_strlen($guia, 'UTF-8') > 40 || mb_strlen($orden, 'UTF-8') > 60) Res::fail('La guía admite hasta 40 caracteres y la orden hasta 60');
        $pendiente = null;
        if (!empty($in['pendiente_id'])) {
            if (!empty($in['id'])) Res::fail('Una factura pendiente solo puede completarse como nueva');
            $pendiente = q("SELECT * FROM pendientes_importacion WHERE id=?", [(int)$in['pendiente_id']])->fetch();
            if (!$pendiente) Res::fail('La factura pendiente ya no existe', 404);
            if (!array_key_exists('retencion', $in) || !in_array($in['retencion'], [true, false, 1, 0, '1', '0'], true))
                Res::fail('Indica si esta factura tiene retención');
            if (q("SELECT COUNT(*) FROM facturas WHERE numero=?", [$pendiente['numero']])->fetchColumn())
                Res::fail('El número de factura pendiente ya está registrado');
        }
        $igvP = (float)Config::get('igv', 18) / 100; $retP = (float)Config::get('retencion', 3) / 100;
        $db = Database::get(); $db->beginTransaction();
        try {
            $sub = 0; $costo = 0; $rows = [];
            $productosAActualizar = array_column($items, 'producto_id');
            foreach ($items as $i) {
                $c = q("SELECT costo FROM productos WHERE id=?", [$i['producto_id']])->fetchColumn();
                if ($c === false || $c === null) $costo = null;
                else {
                    $c = (float)$c;
                    if ($costo !== null) $costo += $i['cantidad'] * $c;
                }
                $precioNeto = (float)$i['precio'] / (1 + $igvP);
                $t = round($i['cantidad'] * $precioNeto * (1 - ($i['descuento'] ?? 0) / 100), 2);
                $sub += $t; $rows[] = [$i, $t, $c, precioUnitarioParaGuardar($i['precio'])];
            }
            $igv = round($sub * $igvP, 2); $tot = $sub + $igv; $ret = !empty($in['retencion']) ? round($tot * $retP, 2) : 0;
            if ($pendiente) {
                $subExcel = round((float)$pendiente['subtotal_excel'], 2);
                $igvExcel = round((float)$pendiente['igv_excel'], 2);
                $totalExcel = round((float)$pendiente['total_excel'], 2);
                if (abs(round($sub, 2) - $subExcel) > 0.01 ||
                    abs($igv - $igvExcel) > 0.01 || abs($tot - $totalExcel) > 0.01) {
                    $db->rollBack();
                    Res::fail('El detalle ingresado no coincide con los importes originales de Excel. Revisa cantidades, precios e IGV.');
                }
            }
            $dias = $in['dias'] ?? 30;
            $ven = $dias === '' ? null : date('Y-m-d', strtotime($emision . ' +' . (int)$dias . ' days'));
            $utilidad = $costo === null ? null : $sub - $costo;
            $v = [$in['cliente_id'], $emision, $ven, $sub, $igv, $tot, $ret, $tot - $ret, $utilidad];
            if (!empty($in['id'])) {
                $id = $in['id'];
                $productosAnteriores = q("SELECT DISTINCT producto_id FROM factura_detalle WHERE factura_id=?", [$id])->fetchAll(PDO::FETCH_COLUMN);
                $productosAActualizar = array_merge($productosAActualizar, $productosAnteriores);
                q("UPDATE facturas SET cliente_id=?,emision=?,vencimiento=?,subtotal=?,igv=?,total=?,retencion=?,total_neto=?,utilidad=?,nro_guia=?,nro_oc=? WHERE id=?", [...$v, $guia, $orden, $id]);
                q("DELETE FROM factura_detalle WHERE factura_id=?", [$id]);
            } else {
                if ($pendiente) $numero = $pendiente['numero'];
                else {
                    // Continúa la serie E001 con números sin ceros a la izquierda.
                    $n = (int)q("SELECT IFNULL(MAX(n),0)+1 FROM (
                        SELECT CAST(SUBSTRING(numero,6) AS UNSIGNED) n FROM facturas WHERE numero LIKE ?
                        UNION ALL
                        SELECT CAST(SUBSTRING(numero,6) AS UNSIGNED) n FROM pendientes_importacion WHERE numero LIKE ?
                    ) numeros", ['E001-%', 'E001-%'])->fetchColumn();
                    $numero = 'E001-' . $n;
                }
                q("INSERT INTO facturas(cliente_id,emision,vencimiento,subtotal,igv,total,retencion,total_neto,utilidad,numero,nro_guia,nro_oc) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    [...$v, $numero, $guia, $orden]);
                $id = $db->lastInsertId();
            }
            foreach ($rows as [$i, $t, $c, $precio])
                q("INSERT INTO factura_detalle(factura_id,producto_id,cantidad,precio,descuento,total,costo_unit) VALUES(?,?,?,?,?,?,?)",
                    [$id, $i['producto_id'], $i['cantidad'], $precio, $i['descuento'] ?? 0, $t, $c]);
            self::sincronizarPreciosCatalogo($productosAActualizar);
            if ($pendiente) q("DELETE FROM pendientes_importacion WHERE id=?", [$pendiente['id']]);
            $db->commit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) $db->rollBack();
            Res::fail($e->getMessage(), 500);
        }
        Res::json(['ok' => 1, 'id' => $id]);
    }
    static function anular($in = []) {
        $productos = q("SELECT DISTINCT producto_id FROM factura_detalle WHERE factura_id=?", [$in['id'] ?? 0])->fetchAll(PDO::FETCH_COLUMN);
        q("UPDATE facturas SET anulada=1,motivo=? WHERE id=?", [$in['motivo'] ?? 'Anulada', $in['id'] ?? 0]);
        self::sincronizarPreciosCatalogo($productos);
        Res::json(['ok' => 1]);
    }
}
