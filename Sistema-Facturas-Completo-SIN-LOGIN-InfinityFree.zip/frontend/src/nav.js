import { LayoutDashboard, FileText, ListChecks, Wallet, Users, Tag, BarChart3, Settings, List } from 'lucide-react';

// k = clave interna, l = texto del menú, s = nombre de la "hoja" (pestaña inferior)
export const NAV = [
  { k: 'dashboard', l: 'Dashboard', i: LayoutDashboard, s: 'DASHBOARD', n: 1, t: 'DASHBOARD' },
  { k: 'facturas', l: 'Facturas', i: FileText, s: 'FACTURAS', n: 2, t: 'FACTURAS (CABECERA)' },
  { k: 'detalle', l: 'Detalle Facturas', i: ListChecks, s: 'DETALLE_FACTURAS', n: 3, t: 'DETALLE DE FACTURAS (PRODUCTOS)' },
  { k: 'cobros', l: 'Cobros', i: Wallet, s: 'COBROS', n: 4, t: 'COBROS' },
  { k: 'clientes', l: 'Clientes', i: Users, s: 'CLIENTES', n: 5, t: 'CLIENTES' },
  { k: 'precios', l: 'Historial Precios', i: Tag, s: 'HISTORIAL_PRECIOS', n: 6, t: 'HISTORIAL DE PRECIOS' },
  { k: 'reportes', l: 'Reportes', i: BarChart3, s: 'REPORTES', n: 7, t: 'REPORTES' },
  { k: 'config', l: 'Configuración', i: Settings, s: 'CONFIGURACION', n: 8, t: 'CONFIGURACIÓN' },
  { k: 'listas', l: 'Listas', i: List, s: 'LISTAS', n: 9, t: 'LISTAS' },
];
