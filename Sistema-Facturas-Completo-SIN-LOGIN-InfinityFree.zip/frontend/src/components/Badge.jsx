export default function Badge({ e }) { return <span className={'badge ' + e}>{e}</span>; }
