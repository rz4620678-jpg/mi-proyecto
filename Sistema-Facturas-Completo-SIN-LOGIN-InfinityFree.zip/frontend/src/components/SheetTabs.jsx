import { NAV } from '../nav';

// Barra inferior estilo hojas de Excel
export default function SheetTabs({ tab, go }) {
  return (
    <footer className="sheets">
      {NAV.map((n) => <button key={n.k} className={tab === n.k ? 'on' : ''} onClick={() => go(n.k)}>{n.s}</button>)}
    </footer>
  );
}
