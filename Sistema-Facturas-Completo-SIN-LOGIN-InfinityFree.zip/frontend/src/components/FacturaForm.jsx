import { useContext, useEffect, useState } from 'react';
import { Ctx } from '../context';
import { api } from '../api';
import { money, priceWithoutIgv, today } from '../utils';
import Modal from './Modal';
import Field from './Field';
import Btn from './Btn';

const blank = { producto_id: '', cantidad: 1, precio: '', descuento: 0 };

export default function FacturaForm({ factura, pendiente, onClose, onSaved }) {
  const { clientes, productos, config } = useContext(Ctx);
  const [f, setF] = useState({
    id: factura?.id, pendiente_id: pendiente?.id, numero: pendiente?.numero,
    cliente_id: factura?.cliente_id || '', emision: factura?.emision || (pendiente ? '' : today()),
    nro_guia: factura?.nro_guia || '', nro_oc: factura?.nro_oc || '',
    dias: factura ? (factura.vencimiento ? Math.round((new Date(factura.vencimiento) - new Date(factura.emision)) / 864e5) : '') : pendiente ? '' : config.dias_credito,
    retencion: factura ? Number(factura.retencion) > 0 : pendiente ? null : true, items: [{ ...blank }],
  });
  useEffect(() => {
    if (factura) api('detalle', { factura_id: factura.id }).then((d) =>
      setF((x) => ({ ...x, items: d.map((i) => ({ producto_id: i.producto_id, cantidad: +i.cantidad, precio: +i.precio, descuento: +i.descuento, es_ajuste: Number(i.es_ajuste) === 1 })) })));
  }, []);

  const setItem = (i, k, v) => {
    const items = [...f.items]; items[i] = { ...items[i], [k]: v };
    if (k === 'producto_id') { const p = productos.find((x) => x.id == v); if (p) items[i].precio = p.precio == null ? '' : +p.precio; }
    setF({ ...f, items });
  };
  const sub = f.items.reduce((s, i) => s + Math.round(priceWithoutIgv(i.cantidad * i.precio * (1 - i.descuento / 100), config.igv) * 100) / 100, 0);
  const igv = sub * config.igv / 100, tot = sub + igv, ret = f.retencion ? tot * config.retencion / 100 : 0;
  const save = async () => { try { await api('factura_guardar', {}, f); onSaved(); } catch (e) { alert(e.error); } };

  return (
    <Modal title={factura ? `Editar factura ${factura.numero}` : pendiente ? `Completar borrador ${pendiente.numero}` : 'Nueva factura'} onClose={onClose} wide>
      {pendiente && (
        <div className="import-alert" role="alert">
          <b>Registro incompleto importado de Excel</b>
          <span>Completa fecha, cliente, retención y detalle. No se inventaron esos datos.</span>
          <span>Importes de referencia: subtotal {money(pendiente.subtotal_excel)}, IGV {money(pendiente.igv_excel)}, total {money(pendiente.total_excel)}.</span>
        </div>
      )}
      <div className="frm">
        <Field label="Cliente"><select value={f.cliente_id} onChange={(e) => setF({ ...f, cliente_id: e.target.value })}><option value="">— Seleccione —</option>{clientes.map((c) => <option key={c.id} value={c.id}>{c.razon_social}</option>)}</select></Field>
        <Field label="Fecha de emisión"><input type="date" value={f.emision} onChange={(e) => setF({ ...f, emision: e.target.value })} /></Field>
        <Field label="Días de crédito"><input type="number" value={f.dias} onChange={(e) => setF({ ...f, dias: e.target.value })} /></Field>
        <Field label={`Retención ${config.retencion}%`}><select value={f.retencion === null ? '' : f.retencion ? 1 : 0} onChange={(e) => setF({ ...f, retencion: e.target.value === '' ? null : e.target.value === '1' })}><option value="">— Seleccione —</option><option value="1">Sí</option><option value="0">No</option></select></Field>
        <Field label="N° de guía"><input maxLength={40} value={f.nro_guia} onChange={(e) => setF({ ...f, nro_guia: e.target.value })} /></Field>
        <Field label="N° de orden de compra"><input maxLength={60} value={f.nro_oc} onChange={(e) => setF({ ...f, nro_oc: e.target.value })} /></Field>
      </div>
      <table className="tbl">
        <thead><tr><th>Producto</th><th>Cantidad</th><th>Precio unit. c/IGV</th><th>Dscto %</th><th>Total c/IGV</th><th></th></tr></thead>
        <tbody>
          {f.items.map((it, i) => (
            <tr key={i}>
              {it.es_ajuste ? (
                <>
                  <td><b>Ajuste de conciliación (no es producto)</b></td>
                  <td>{it.cantidad}</td><td>{money(it.precio)}</td><td>—</td>
                  <td className="n">{money(it.cantidad * it.precio)}</td><td></td>
                </>
              ) : (
                <>
                  <td><select value={it.producto_id} onChange={(e) => setItem(i, 'producto_id', e.target.value)}><option value="">—</option>{productos.map((p) => <option key={p.id} value={p.id}>{p.nombre}</option>)}</select></td>
                  <td><input type="number" value={it.cantidad} onChange={(e) => setItem(i, 'cantidad', +e.target.value)} /></td>
                  <td><input type="number" step="0.01" placeholder="Sin historial" value={it.precio} onChange={(e) => setItem(i, 'precio', e.target.value === '' ? '' : +e.target.value)} /></td>
                  <td><input type="number" value={it.descuento} onChange={(e) => setItem(i, 'descuento', +e.target.value)} /></td>
                  <td className="n">{money(it.cantidad * it.precio * (1 - it.descuento / 100))}</td>
                  <td><Btn c="rd s" onClick={() => setF({ ...f, items: f.items.filter((_, j) => j !== i) })}>✕</Btn></td>
                </>
              )}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="bar"><Btn c="bl s" onClick={() => setF({ ...f, items: [...f.items, { ...blank }] })}>+ Agregar ítem</Btn>{f.items.some((i) => i.es_ajuste) && <small>La línea de ajuste se conserva para cuadrar el subtotal original del Excel.</small>}</div>
      <div className="resumen"><span>Subtotal: <b>{money(sub)}</b></span><span>IGV ({config.igv}%): <b>{money(igv)}</b></span><span>Total: <b>{money(tot)}</b></span><span>Retención: <b>{money(ret)}</b></span><span>Total neto: <b>{money(tot - ret)}</b></span></div>
      <div className="bar"><Btn c="gr" onClick={save}>Guardar</Btn><Btn c="rd" onClick={onClose}>Cancelar</Btn></div>
    </Modal>
  );
}
