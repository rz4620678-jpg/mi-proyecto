import { useContext } from 'react';
import { Ctx } from '../context';
import { NAV } from '../nav';

export default function PageHeader({ k }) {
  const n = NAV.find((x) => x.k === k);
  return <div className="pestana">{n.n}. PESTAÑA: {n.t}</div>;
}
