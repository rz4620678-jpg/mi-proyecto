import { HelpCircle } from 'lucide-react';
import { NAV } from '../nav';

export default function Sidebar({ tab, go, empresa }) {
  return (
    <aside className="side">
      <div className="logo">
        <svg width="46" height="34" viewBox="0 0 46 34"><rect x="4" y="20" width="7" height="12" fill="#1e9e48" /><rect x="14" y="14" width="7" height="18" fill="#1e9e48" /><rect x="24" y="8" width="7" height="24" fill="#1e9e48" /><path d="M3 14 L20 4 L28 8 L42 0" stroke="#1d4fb5" strokeWidth="3" fill="none" /></svg>
        <div>{empresa}</div>
      </div>
      {NAV.map((n) => (
        <button key={n.k} className={'nav' + (tab === n.k ? ' on' : '')} onClick={() => go(n.k)}><n.i size={16} />{n.l}</button>
      ))}
      <button className="nav" onClick={() => alert('Ayuda:\n• Selecciona una fila para Editar o Eliminar.\n• Las facturas con retención 3% se calculan sobre el total.\n• Estados: Pendiente, Parcial, Vencida, Cobrada y Anulada se calculan solos.')}><HelpCircle size={16} />Ayuda</button>
    </aside>
  );
}
