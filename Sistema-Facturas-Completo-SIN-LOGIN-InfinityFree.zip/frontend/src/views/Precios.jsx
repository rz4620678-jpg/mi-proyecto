import { useContext, useState } from 'react';
import { Ctx } from '../context';
import { useApi } from '../api';
import { money, fdate, priceWithIgv } from '../utils';
import PageHeader from '../components/PageHeader';
import DataTable from '../components/DataTable';

export default function Precios() {
  const { productos, clientes, config } = useContext(Ctx);
  const [p, setP] = useState(productos[0]?.id || 1);
  const [c, setC] = useState('');
  const rows = useApi('precios', { producto_id: p, cliente_id: c });
  const cols = [
    { h: 'Fecha', render: (r) => fdate(r.fecha) }, { h: 'Factura', k: 'factura' }, { h: 'Cliente', k: 'cliente', cls: 'l' },
    { h: 'Cantidad', render: (r) => Number(r.cantidad) }, { h: 'Precio Unit. c/IGV', render: (r) => money(r.precio), cls: 'n' }, { h: 'Precio Total c/IGV', render: (r) => money(priceWithIgv(r.total, config.igv)), cls: 'n' },
  ];
  return (
    <>
      <PageHeader k="precios" />
      <div className="titlebar"><h2>HISTORIAL DE PRECIOS POR PRODUCTO</h2></div>
      <div className="filtros">
        <label>Producto: <select value={p} onChange={(e) => setP(e.target.value)}>{productos.map((x) => <option key={x.id} value={x.id}>{x.nombre}</option>)}</select></label>
        <label>Cliente: <select value={c} onChange={(e) => setC(e.target.value)}><option value="">TODOS</option>{clientes.map((x) => <option key={x.id} value={x.id}>{x.razon_social}</option>)}</select></label>
      </div>
      <DataTable cols={cols} rows={rows} />
    </>
  );
}
