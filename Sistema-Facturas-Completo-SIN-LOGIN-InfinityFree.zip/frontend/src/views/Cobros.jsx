import { useContext, useState } from 'react';
import { Plus, Pencil, Trash2, FileSpreadsheet } from 'lucide-react';
import { Ctx } from '../context';
import { api, useApi } from '../api';
import { money, fdate, today, exportCsv } from '../utils';
import PageHeader from '../components/PageHeader';
import DataTable from '../components/DataTable';
import Btn from '../components/Btn';
import Modal from '../components/Modal';
import Field from '../components/Field';

const NOMBRES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'];

export default function Cobros() {
  const { intent, listas } = useContext(Ctx);
  const [mes, setMes] = useState('');
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(null);
  const [form, setForm] = useState(intent === 'nuevo' ? { fecha: today(), banco: listas.banco[0]?.nombre, forma_pago: listas.forma_pago[0]?.nombre, observaciones: '' } : null);
  const [t, setT] = useState(0);
  const anio = new Date().getFullYear();
  const rows = useApi('cobros', { mes: mes && `${anio}-${mes}`, q }, [t]);
  const facturas = (useApi('facturas', {}, [t]) || []).filter((f) => f.estado !== 'ANULADA' && (f.saldo > 0 || f.id == form?.factura_id));

  const cols = [
    { h: 'Fecha Cobro', render: (r) => r.fecha ? fdate(r.fecha) : 'Sin fecha registrada' }, { h: 'Factura', k: 'factura' }, { h: 'Cliente', k: 'cliente', cls: 'l' },
    { h: 'Monto Cobrado', render: (r) => money(r.monto), cls: 'n' }, { h: 'Banco', render: (r) => r.banco || '—' }, { h: 'Forma de Pago', render: (r) => r.forma_pago || '—' },
    { h: 'Observaciones', render: (r) => {
      if (!r.observaciones) return '—';
      const text = r.observaciones.replace(/\bimportad[oa]s? (?:del|desde(?: el)?) Excel\b/gi, 'registro histórico');
      return text.charAt(0).toUpperCase() + text.slice(1);
    } },
    { h: 'Registrado por', render: (r) => /^(?:IMPORTACION|IMPORTACION EXCEL)$/i.test(r.registrado_por || '') ? 'Histórico' : r.registrado_por || '—' },
  ];
  const nuevo = () => setForm({ fecha: today(), banco: listas.banco[0]?.nombre, forma_pago: listas.forma_pago[0]?.nombre, observaciones: '' });
  const editar = () => (sel ? setForm({ ...sel, monto: +sel.monto }) : alert('Selecciona un cobro'));
  const eliminar = async () => { if (!sel) return alert('Selecciona un cobro'); if (confirm('¿Eliminar este cobro?')) { await api('cobro_eliminar', {}, { id: sel.id }); setSel(null); setT(t + 1); } };
  const guardar = async () => { try { await api('cobro_guardar', {}, form); setForm(null); setT(t + 1); } catch (e) { alert(e.error); } };
  const set = (k, v) => setForm({ ...form, [k]: v });

  return (
    <>
      <PageHeader k="cobros" />
      <div className="titlebar"><h2>REGISTRO DE COBROS</h2>
        <div><Btn c="gr" icon={Plus} onClick={nuevo}>NUEVO COBRO</Btn><Btn c="bl" icon={Pencil} onClick={editar}>EDITAR</Btn><Btn c="rd" icon={Trash2} onClick={eliminar}>ELIMINAR</Btn><Btn c="gr" icon={FileSpreadsheet} onClick={() => exportCsv(rows, 'cobros')}>EXPORTAR</Btn></div>
      </div>
      <div className="filtros">
        <label>Filtrar por Mes: <select value={mes} onChange={(e) => setMes(e.target.value)}><option value="">TODOS</option>{NOMBRES.map((n, i) => <option key={n} value={String(i + 1).padStart(2, '0')}>{n}</option>)}</select></label>
        <label>Buscar: <input placeholder="Buscar por factura o cliente..." value={q} onChange={(e) => setQ(e.target.value)} /></label>
      </div>
      <DataTable cols={cols} rows={rows} selected={sel} onSelect={setSel} />
      {form && (
        <Modal title={form.id ? 'Editar cobro' : 'Registrar cobro'} onClose={() => setForm(null)}>
          <div className="frm">
            <Field label="Factura"><select value={form.factura_id || ''} onChange={(e) => { const f = facturas.find((x) => x.id == e.target.value); setForm({ ...form, factura_id: e.target.value, monto: f ? +f.saldo : '' }); }}><option value="">— Seleccione —</option>{facturas.map((f) => <option key={f.id} value={f.id}>{f.numero} · {f.cliente} · saldo {money(f.saldo)}</option>)}</select></Field>
            <Field label="Fecha de cobro"><input type="date" value={form.fecha} onChange={(e) => set('fecha', e.target.value)} /></Field>
            <Field label="Monto"><input type="number" value={form.monto || ''} onChange={(e) => set('monto', +e.target.value)} /></Field>
            <Field label="Banco"><select value={form.banco || ''} onChange={(e) => set('banco', e.target.value)}><option value="">— Sin registrar —</option>{listas.banco.map((b) => <option key={b.id} value={b.nombre}>{b.nombre}</option>)}</select></Field>
            <Field label="Forma de pago"><select value={form.forma_pago || ''} onChange={(e) => set('forma_pago', e.target.value)}><option value="">— Sin registrar —</option>{listas.forma_pago.map((b) => <option key={b.id} value={b.nombre}>{b.nombre}</option>)}</select></Field>
            <Field label="Observaciones"><input value={form.observaciones} onChange={(e) => set('observaciones', e.target.value)} /></Field>
          </div>
          <div className="bar"><Btn c="gr" onClick={guardar}>Guardar</Btn><Btn c="rd" onClick={() => setForm(null)}>Cancelar</Btn></div>
        </Modal>
      )}
    </>
  );
}
