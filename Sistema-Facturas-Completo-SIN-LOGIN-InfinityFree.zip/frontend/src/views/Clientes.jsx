import { useContext, useState } from 'react';
import { Plus, Pencil, Trash2, FileSpreadsheet } from 'lucide-react';
import { Ctx } from '../context';
import { api, useApi } from '../api';
import { money, fdate, exportCsv } from '../utils';
import PageHeader from '../components/PageHeader';
import DataTable from '../components/DataTable';
import Btn from '../components/Btn';
import Modal from '../components/Modal';
import Field from '../components/Field';

const CAMPOS = [['razon_social', 'Razón social'], ['ruc', 'RUC (11 dígitos)'], ['telefono', 'Teléfono'], ['email', 'Email'], ['direccion', 'Dirección']];

export default function Clientes() {
  const { reload } = useContext(Ctx);
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(null);
  const [form, setForm] = useState(null);
  const [t, setT] = useState(0);
  const rows = useApi('clientes', { q }, [t]);
  const cols = [
    { h: 'Cliente', k: 'razon_social', cls: 'l' }, { h: 'RUC', k: 'ruc' }, { h: 'Teléfono', render: (r) => r.telefono || '—' }, { h: 'Email', render: (r) => r.email || '—' },
    { h: 'Dirección', render: (r) => r.direccion || '—', cls: 'l' }, { h: 'N° facturas', k: 'facturas' },
    { h: 'Última factura', render: (r) => fdate(r.ultima_factura) || '-' },
    { h: 'Saldo por Cobrar (S/)', render: (r) => money(r.saldo), cls: 'n pos' },
  ];
  const guardar = async () => { try { await api('cliente_guardar', {}, form); setForm(null); setT(t + 1); reload(); } catch (e) { alert(e.error); } };
  const eliminar = async () => {
    if (!sel) return alert('Selecciona un cliente');
    if (!confirm('¿Eliminar cliente?')) return;
    try { await api('cliente_eliminar', {}, { id: sel.id }); setSel(null); setT(t + 1); reload(); } catch (e) { alert(e.error); }
  };
  return (
    <>
      <PageHeader k="clientes" />
      <div className="titlebar"><h2>LISTA DE CLIENTES</h2>
        <div><Btn c="gr" icon={Plus} onClick={() => setForm({})}>NUEVO CLIENTE</Btn><Btn c="bl" icon={Pencil} onClick={() => (sel ? setForm(sel) : alert('Selecciona un cliente'))}>EDITAR</Btn><Btn c="rd" icon={Trash2} onClick={eliminar}>ELIMINAR</Btn><Btn c="gr" icon={FileSpreadsheet} onClick={() => exportCsv(rows, 'clientes')}>EXPORTAR</Btn></div>
      </div>
      <div className="filtros"><label>Buscar: <input placeholder="Buscar por cliente o RUC..." value={q} onChange={(e) => setQ(e.target.value)} /></label></div>
      <DataTable cols={cols} rows={rows} selected={sel} onSelect={setSel} />
      {form && (
        <Modal title={form.id ? 'Editar cliente' : 'Nuevo cliente'} onClose={() => setForm(null)}>
          <div className="frm">{CAMPOS.map(([k, l]) => <Field key={k} label={l}><input value={form[k] || ''} onChange={(e) => setForm({ ...form, [k]: e.target.value })} /></Field>)}</div>
          <div className="bar"><Btn c="gr" onClick={guardar}>Guardar</Btn><Btn c="rd" onClick={() => setForm(null)}>Cancelar</Btn></div>
        </Modal>
      )}
    </>
  );
}
