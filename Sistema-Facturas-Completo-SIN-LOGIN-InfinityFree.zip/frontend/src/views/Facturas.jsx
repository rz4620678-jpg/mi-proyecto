import { useContext, useEffect, useState } from 'react';
import { Plus, Pencil, CircleX, FileSpreadsheet } from 'lucide-react';
import { Ctx } from '../context';
import { api, useApi } from '../api';
import { money, fdate, exportCsv, COLOR_ESTADO } from '../utils';
import PageHeader from '../components/PageHeader';
import DataTable from '../components/DataTable';
import Badge from '../components/Badge';
import Btn from '../components/Btn';
import Modal from '../components/Modal';
import FacturaForm from '../components/FacturaForm';

const ANIOS = [2026, 2025, 2024, 2023, 2022, 2021];

export default function Facturas() {
  const { intent, listas, config } = useContext(Ctx);
  const [anio, setAnio] = useState('');
  const [estado, setEstado] = useState('');
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(null);
  const [form, setForm] = useState(intent === 'nuevo' ? {} : null);
  const [anular, setAnular] = useState(null);
  const [t, setT] = useState(0);
  const rows = useApi('facturas', { anio, estado, q }, [t]);
  const pendientes = useApi('pendientes_importacion');
  const pendingId = typeof intent === 'string' && intent.startsWith('pendiente-') ? Number(intent.slice('pendiente-'.length)) : null;

  useEffect(() => {
    if (!pendingId || !pendientes) return;
    const pendiente = pendientes.find((p) => Number(p.id) === pendingId);
    if (pendiente) setForm({ pendiente });
  }, [pendingId, pendientes]);

  const cols = [
    { h: 'Fecha Emisión', render: (r) => fdate(r.emision) }, { h: 'Factura', k: 'numero' }, { h: 'Guía', k: 'nro_guia' }, { h: 'O/C', k: 'nro_oc' },
    { h: 'Cliente', k: 'cliente', cls: 'l' }, { h: 'RUC', k: 'ruc' },
    { h: 'Vencimiento', render: (r) => r.vencimiento ? fdate(r.vencimiento) : 'Sin dato' }, { h: 'Subtotal', render: (r) => money(r.subtotal), cls: 'n' },
    { h: `IGV (${config.igv}%)`, render: (r) => money(r.igv), cls: 'n' }, { h: 'Total', render: (r) => money(r.total), cls: 'n' },
    { h: `Retención ${config.retencion}%`, render: (r) => money(r.retencion), cls: 'n' }, { h: 'Total Neto', render: (r) => money(r.total_neto), cls: 'n' },
    { h: 'Excedente no aplicado', render: (r) => Number(r.excedente) > 0 ? money(r.excedente) : '-' , cls: 'n' },
    { h: 'Estado', render: (r) => <Badge e={r.estado} /> }, { h: 'Días Pend.', render: (r) => r.estado === 'COBRADA' || r.estado === 'ANULADA' || r.dias == null ? '-' : <b className={r.dias < 0 ? 'neg' : ''}>{r.dias}</b> },
    { h: 'Banco', render: (r) => r.banco || '-' }, { h: 'Utilidad', render: (r) => r.utilidad == null ? 'Sin dato' : money(r.utilidad), cls: 'n pos' },
    { h: 'Anulada', render: (r) => (r.anulada == 1 ? 'Sí' : 'No') },
  ];
  const editar = () => (sel ? setForm(sel) : alert('Selecciona una factura de la lista'));
  const eliminar = () => (sel ? setAnular({ id: sel.id, numero: sel.numero, motivo: listas.motivo[0]?.nombre || 'Anulada' }) : alert('Selecciona una factura de la lista'));
  const confirmarAnular = async () => { await api('factura_anular', {}, anular); setAnular(null); setSel(null); setT(t + 1); };
  const guardado = () => { setForm(null); setT(t + 1); };

  return (
    <>
      <PageHeader k="facturas" />
      <div className="titlebar"><h2>LISTADO DE FACTURAS ({rows?.length ?? '…'})</h2>
        <div><Btn c="gr" icon={Plus} onClick={() => setForm({})}>NUEVA FACTURA</Btn><Btn c="bl" icon={Pencil} onClick={editar}>EDITAR</Btn><Btn c="rd" icon={CircleX} onClick={eliminar}>ANULAR</Btn><Btn c="gr" icon={FileSpreadsheet} onClick={() => exportCsv(rows, 'facturas')}>EXPORTAR</Btn></div>
      </div>
      <div className="filtros">
        <label>Filtrar por Año: <select value={anio} onChange={(e) => setAnio(e.target.value)}><option value="">TODOS</option>{ANIOS.map((x) => <option key={x} value={x}>{x}</option>)}</select></label>
        <label>Filtrar por Estado: <select value={estado} onChange={(e) => setEstado(e.target.value)}><option value="">TODOS</option>{Object.keys(COLOR_ESTADO).map((x) => <option key={x}>{x}</option>)}</select></label>
        <label>Buscar: <input placeholder="Buscar por factura, guía, O/C, cliente o RUC..." value={q} onChange={(e) => setQ(e.target.value)} /></label>
      </div>
      <DataTable cols={cols} rows={rows} selected={sel} onSelect={setSel} />
      {pendingId && pendientes && !pendientes.some((p) => Number(p.id) === pendingId) && !form && <div className="import-alert" role="status">El registro pendiente ya no existe o fue completado.</div>}
      {form && <FacturaForm factura={form.id ? form : null} pendiente={form.pendiente} onClose={() => setForm(null)} onSaved={guardado} />}
      {anular && (
        <Modal title={`Anular ${anular.numero}`} onClose={() => setAnular(null)}>
          <p>La factura no se borrará: se conservará en el historial con estado ANULADA.</p>
          <label className="field">Motivo de anulación<select value={anular.motivo} onChange={(e) => setAnular({ ...anular, motivo: e.target.value })}>{listas.motivo.map((m) => <option key={m.id}>{m.nombre}</option>)}</select></label>
          <div className="bar"><Btn c="rd" onClick={confirmarAnular}>Anular factura</Btn><Btn c="nv" onClick={() => setAnular(null)}>Cancelar</Btn></div>
        </Modal>
      )}
    </>
  );
}
