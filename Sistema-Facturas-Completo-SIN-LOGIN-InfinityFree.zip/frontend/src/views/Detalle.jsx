import { useContext, useState } from 'react';
import { Ctx } from '../context';
import { useApi } from '../api';
import { money, priceWithIgv } from '../utils';
import PageHeader from '../components/PageHeader';
import DataTable from '../components/DataTable';

export default function Detalle() {
  const { config } = useContext(Ctx);
  const [fid, setFid] = useState('');
  const [q, setQ] = useState('');
  const facturas = useApi('facturas') || [];
  const rows = useApi('detalle', { factura_id: fid, q });
  const f = facturas.find((x) => x.id == fid);
  const cols = [
    { h: 'Factura', k: 'factura' }, { h: 'Producto', k: 'producto', cls: 'l' }, { h: 'Marca', k: 'marca' }, { h: 'Presentación', k: 'presentacion' },
    { h: 'Cantidad', render: (r) => Number(r.cantidad) }, { h: 'Unidad', k: 'unidad' },
    { h: 'Precio Unit. c/IGV', render: (r) => money(r.precio), cls: 'n' },
    { h: 'Descuento %', render: (r) => Number(r.descuento) + '%' }, { h: 'Total c/IGV', render: (r) => money(priceWithIgv(r.total, config.igv)), cls: 'n' },
  ];
  return (
    <>
      <PageHeader k="detalle" />
      <div className="titlebar"><h2>DETALLE DE PRODUCTOS POR FACTURA</h2></div>
      <div className="filtros">
        <label>Filtrar por Factura: <select value={fid} onChange={(e) => setFid(e.target.value)}><option value="">TODOS</option>{facturas.map((x) => <option key={x.id} value={x.id}>{x.numero}</option>)}</select></label>
        <label>Buscar producto: <input placeholder="Buscar producto..." value={q} onChange={(e) => setQ(e.target.value)} /></label>
      </div>
      <DataTable cols={cols} rows={rows} />
      {f && (
        <div className="resumen caja">
          <b>RESUMEN DE LA FACTURA {f.numero}</b>
          <span>Subtotal: <b>{money(f.subtotal)}</b></span><span>IGV ({config.igv}%): <b>{money(f.igv)}</b></span><span>Total: <b>{money(f.total)}</b></span>
          <span>Retención {config.retencion}%: <b>{money(f.retencion)}</b></span><span>Total Neto: <b>{money(f.total_neto)}</b></span>
        </div>
      )}
    </>
  );
}
