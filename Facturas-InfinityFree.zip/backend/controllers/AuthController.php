<?php
class AuthController {
    static function login($in = []) {
        $u = q("SELECT * FROM usuarios WHERE usuario=?", [$in['usuario'] ?? ''])->fetch();
        $clave = (string)($in['clave'] ?? '');
        $hash = $u['clave'] ?? '';
        $valida = $u && (
            hash_equals($hash, hash('sha256', $clave)) ||
            (strlen($hash) === 40 && hash_equals($hash, sha1($clave)))
        );
        if ($valida) {
            $_SESSION['u'] = $u['nombre']; $_SESSION['rol'] = $u['rol'];
            Res::json(['nombre' => $u['nombre'], 'rol' => $u['rol']]);
        }
        Res::fail('Usuario o clave incorrectos', 401);
    }
    static function me($in = []) { Res::json(['nombre' => $_SESSION['u'] ?? null]); }
    static function logout($in = []) { session_destroy(); Res::json(['ok' => 1]); }
}
