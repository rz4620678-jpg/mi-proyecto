<?php
// Productos, listas (bancos, formas de pago, motivos), historial de precios y datos iniciales
class CatalogoController {
    static function bootstrap($in = []) {
        $l = ['banco' => [], 'forma_pago' => [], 'motivo' => []];
        foreach (q("SELECT * FROM listas ORDER BY nombre")->fetchAll() as $r) $l[$r['tipo']][] = $r;
        $productos = q("SELECT p.id,p.nombre,p.marca,p.presentacion,p.unidad,
                    (SELECT d.precio
                     FROM factura_detalle d
                     JOIN facturas f ON f.id = d.factura_id
                     WHERE d.producto_id = p.id AND f.anulada = 0
                     ORDER BY f.emision DESC, f.id DESC, d.id DESC
                     LIMIT 1) AS precio,
                    p.costo,p.es_ajuste
                FROM productos p
                WHERE p.es_ajuste=0
                ORDER BY p.nombre")->fetchAll();
        foreach ($productos as &$producto)
            $producto['precio'] = precioUnitarioConIgv($producto['precio']);
        unset($producto);
        Res::json([
            'clientes' => q("SELECT id,razon_social FROM clientes ORDER BY razon_social")->fetchAll(),
            'productos' => $productos,
            'listas' => $l, 'config' => Config::all(), 'user' => $_SESSION['u'],
        ]);
    }
    static function precios($in = []) {
        $rows = q("SELECT f.emision fecha,f.numero factura,c.razon_social cliente,d.cantidad,d.precio,d.total
            FROM factura_detalle d JOIN facturas f ON f.id=d.factura_id JOIN clientes c ON c.id=f.cliente_id
            WHERE d.producto_id=? AND (?='' OR f.cliente_id=?) ORDER BY f.emision DESC",
            [$_GET['producto_id'] ?? 0, $_GET['cliente_id'] ?? '', $_GET['cliente_id'] ?? ''])->fetchAll();
        foreach ($rows as &$row) $row['precio'] = precioUnitarioConIgv($row['precio']);
        unset($row);
        Res::json($rows);
    }
    static function listaGuardar($in = []) {
        if (!in_array($in['tipo'] ?? '', ['banco', 'forma_pago', 'motivo']) || empty($in['nombre'])) Res::fail('Datos inválidos');
        q("INSERT INTO listas(tipo,nombre) VALUES(?,?)", [$in['tipo'], $in['nombre']]); Res::json(['ok' => 1]);
    }
    static function listaEliminar($in = []) { q("DELETE FROM listas WHERE id=?", [$in['id'] ?? 0]); Res::json(['ok' => 1]); }
    static function productoGuardar($in = []) {
        if (empty($in['nombre'])) Res::fail('Falta el nombre');
        $costo = $in['costo'] ?? '';
        if ($costo !== '' && !is_numeric($costo)) Res::fail('El costo debe ser numérico');
        q("INSERT INTO productos(nombre,marca,presentacion,unidad,costo) VALUES(?,?,?,?,?)",
            [strtoupper($in['nombre']), $in['marca'] ?? '', $in['presentacion'] ?? '', $in['unidad'] ?? 'UND', $costo === '' ? null : $costo]);
        Res::json(['ok' => 1]);
    }
    static function productoEliminar($in = []) {
        if (q("SELECT COUNT(*) FROM factura_detalle WHERE producto_id=?", [$in['id'] ?? 0])->fetchColumn()) Res::fail('El producto ya se usó en facturas');
        q("DELETE FROM productos WHERE id=?", [$in['id']]); Res::json(['ok' => 1]);
    }
}
