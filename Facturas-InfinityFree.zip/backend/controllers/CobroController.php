<?php
class CobroController {
    static function listar($in = []) {
        $w = '1'; $p = [];
        if (!empty($_GET['mes'])) { $w .= " AND DATE_FORMAT(o.fecha,'%Y-%m')=?"; $p[] = $_GET['mes']; }
        if (!empty($_GET['q'])) { $l = '%' . $_GET['q'] . '%'; $w .= ' AND (f.numero LIKE ? OR c.razon_social LIKE ?)'; array_push($p, $l, $l); }
        Res::json(q("SELECT o.*,f.numero factura,c.razon_social cliente FROM cobros o JOIN facturas f ON f.id=o.factura_id
            JOIN clientes c ON c.id=f.cliente_id WHERE $w ORDER BY o.fecha DESC,o.id DESC", $p)->fetchAll());
    }
    static function guardar($in = []) {
        $f = q("SELECT saldo,estado FROM v_facturas WHERE id=?", [$in['factura_id'] ?? 0])->fetch();
        if (!$f || $f['estado'] === 'ANULADA') Res::fail('Factura inválida');
        $saldo = (float)$f['saldo'] + (!empty($in['id']) ? (float)q("SELECT monto FROM cobros WHERE id=?", [$in['id']])->fetchColumn() : 0);
        $m = (float)($in['monto'] ?? 0);
        if ($m <= 0 || $m > $saldo + 0.001) Res::fail('Monto inválido. Saldo disponible: ' . number_format($saldo, 2));
        $v = [$in['factura_id'], $in['fecha'], $m, $in['banco'] ?? '', $in['forma_pago'] ?? '', $in['observaciones'] ?? ''];
        if (!empty($in['id'])) q("UPDATE cobros SET factura_id=?,fecha=?,monto=?,banco=?,forma_pago=?,observaciones=? WHERE id=?", [...$v, $in['id']]);
        else q("INSERT INTO cobros(factura_id,fecha,monto,banco,forma_pago,observaciones,registrado_por) VALUES(?,?,?,?,?,?,?)", [...$v, $_SESSION['u']]);
        Res::json(['ok' => 1]);
    }
    static function eliminar($in = []) { q("DELETE FROM cobros WHERE id=?", [$in['id'] ?? 0]); Res::json(['ok' => 1]); }
}
