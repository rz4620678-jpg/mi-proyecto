<?php
class ConfigController {
    const KEYS = ['empresa_nombre','empresa_ruc','empresa_direccion','empresa_telefono','empresa_email','igv','retencion','dias_credito','color'];
    static function guardar($in = []) {
        foreach (($in['valores'] ?? []) as $k => $v) if (in_array($k, self::KEYS)) Config::set($k, $v);
        Res::json(['ok' => 1]);
    }
    static function usuarios($in = []) { Res::json(q("SELECT id,usuario,nombre,rol FROM usuarios ORDER BY id")->fetchAll()); }
    static function usuarioGuardar($in = []) {
        if (empty($in['usuario']) || empty($in['clave'])) Res::fail('Usuario y clave son obligatorios');
        q("INSERT INTO usuarios(usuario,clave,nombre,rol) VALUES(?,?,?,?)", [$in['usuario'], hash('sha256', $in['clave']), strtoupper($in['nombre'] ?? $in['usuario']), $in['rol'] ?? 'USUARIO']);
        Res::json(['ok' => 1]);
    }
    static function usuarioEliminar($in = []) {
        if (q("SELECT COUNT(*) FROM usuarios")->fetchColumn() <= 1) Res::fail('Debe quedar al menos un usuario');
        q("DELETE FROM usuarios WHERE id=?", [$in['id'] ?? 0]); Res::json(['ok' => 1]);
    }
    // Respaldo de datos: descarga un .sql con los INSERT de todas las tablas
    static function respaldo($in = []) {
        $db = Database::get();
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="respaldo_' . date('Ymd_His') . '.sql"');
        echo "SET FOREIGN_KEY_CHECKS=0;\n";
        $tables = ['usuarios','clientes','productos','listas','configuracion'];
        if (q("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?", ['pendientes_importacion'])->fetchColumn()) $tables[] = 'pendientes_importacion';
        foreach (array_merge($tables, ['facturas','factura_detalle','cobros']) as $t) {
            echo "DELETE FROM `$t`;\n";
            foreach (q("SELECT * FROM `$t`")->fetchAll() as $r)
                echo "INSERT INTO `$t`(`" . implode('`,`', array_keys($r)) . "`) VALUES(" .
                    implode(',', array_map(fn($v) => $v === null ? 'NULL' : $db->quote($v), $r)) . ");\n";
        }
        echo "SET FOREIGN_KEY_CHECKS=1;\n"; exit;
    }
}
