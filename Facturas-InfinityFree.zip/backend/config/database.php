<?php
// Conexión PDO. Cambia aquí tus credenciales de MySQL.
class Database {
    private static ?PDO $pdo = null;
    static function get(): PDO {
        if (self::$pdo === null) {
            $host = getenv('FACTURAS_DB_HOST') ?: 'sql106.infinityfree.com';
            $port = (int)(getenv('FACTURAS_DB_PORT') ?: 3306);
            $name = getenv('FACTURAS_DB_NAME') ?: 'if0_43237618_facturas_cobrar';
            $user = getenv('FACTURAS_DB_USER') ?: 'if0_43237618';
            $pass = getenv('FACTURAS_DB_PASSWORD') ?: 'IyAb7eSsp1R41';
            self::$pdo = new PDO(
                "mysql:host=$host;port=$port;dbname=$name;charset=utf8mb4",
                $user,
                $pass,
                [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci',
                ]
            );
        }
        return self::$pdo;
    }
}
