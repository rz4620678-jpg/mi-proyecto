<?php
// Único punto de entrada: api.php?r=<ruta>  ->  Controlador::método
session_start();
header('Content-Type: application/json; charset=utf-8');
foreach (['config/database', 'core/Support', 'controllers/AuthController', 'controllers/FacturaController', 'controllers/ClienteController',
    'controllers/CobroController', 'controllers/DashboardController', 'controllers/CatalogoController', 'controllers/ConfigController',
    'controllers/ReporteController'] as $f) require __DIR__ . "/$f.php";

$routes = [
    'login' => ['AuthController', 'login'], 'me' => ['AuthController', 'me'], 'logout' => ['AuthController', 'logout'],
    'bootstrap' => ['CatalogoController', 'bootstrap'], 'dashboard' => ['DashboardController', 'resumen'],
    'facturas' => ['FacturaController', 'listar'], 'detalle' => ['FacturaController', 'detalle'],
    'pendientes_importacion' => ['FacturaController', 'pendientes'],
    'factura_guardar' => ['FacturaController', 'guardar'], 'factura_anular' => ['FacturaController', 'anular'],
    'clientes' => ['ClienteController', 'listar'], 'cliente_guardar' => ['ClienteController', 'guardar'], 'cliente_eliminar' => ['ClienteController', 'eliminar'],
    'cobros' => ['CobroController', 'listar'], 'cobro_guardar' => ['CobroController', 'guardar'], 'cobro_eliminar' => ['CobroController', 'eliminar'],
    'precios' => ['CatalogoController', 'precios'], 'lista_guardar' => ['CatalogoController', 'listaGuardar'], 'lista_eliminar' => ['CatalogoController', 'listaEliminar'],
    'producto_guardar' => ['CatalogoController', 'productoGuardar'], 'producto_eliminar' => ['CatalogoController', 'productoEliminar'],
    'reporte' => ['ReporteController', 'generar'],
    'config_guardar' => ['ConfigController', 'guardar'], 'usuarios' => ['ConfigController', 'usuarios'],
    'usuario_guardar' => ['ConfigController', 'usuarioGuardar'], 'usuario_eliminar' => ['ConfigController', 'usuarioEliminar'], 'respaldo' => ['ConfigController', 'respaldo'],
];
$r = $_GET['r'] ?? '';
if (!isset($routes[$r])) Res::fail('Ruta no existe', 404);
if (!in_array($r, ['login', 'me', 'logout']) && empty($_SESSION['u'])) Res::fail('No autorizado', 401);
try { [$c, $m] = $routes[$r]; $c::$m(Res::body()); }
catch (Throwable $e) { Res::fail($e->getMessage(), 500); }
